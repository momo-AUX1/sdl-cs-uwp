# Dependencies

The sample's dependencies are comprised of the following projects:

- Aerisarn's mesa-uwp fork: https://github.com/aerisarn/mesa-uwp
- Aerisarn's SDL fork that adds OpenGL compatibiliy on UWP: https://github.com/aerisarn/sdl-uwp-gl
  - Note: Built using the VisualC-WinRT project
- GLAD for loading GL extensions/functions
- UGL for porting and using SDL/Mesa to UGL/ANGLE 
